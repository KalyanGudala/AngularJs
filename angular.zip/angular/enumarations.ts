enum courseNames
{
    Java,Springboot,MicroServices,Angularjs,Reactjs,JavaScript
}

class Student
{
    studentname:string;
    age:number;
    course:courseNames;
}

var s=new Student();
s.studentname="Scott";
s.age=20;
s.course=courseNames.MicroServices;
console.log(s.studentname);
console.log(s.age);
console.log(courseNames[s.course])
