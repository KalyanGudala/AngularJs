export class Student
{
    studentId:number;
    studentName:string;
    marks: number;

    constructor(studentId:number,studentName:string,marks:number)
    {
       this.studentId=studentId;
       this.studentName=studentName;
       this.marks=marks;

    }

}