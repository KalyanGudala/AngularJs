"use strict";
exports.__esModule = true;
var Student_1 = require("./Student");
var StudentsList = /** @class */ (function () {
    function StudentsList() {
        this.students = [
            new Student_1.Student(101, "Scott", 80),
            new Student_1.Student(102, "Adams", 90),
            new Student_1.Student(103, "John", 100),
            new Student_1.Student(104, "David", 110)
        ];
    }
    StudentsList.prototype.getTopRankers = function () {
        var index;
        var max = 0;
        for (var i in this.students) {
            if (this.students[i].marks > max) {
                index = i;
            }
        }
        return this.students[index];
    };
    return StudentsList;
}());
var s = new StudentsList();
console.log(s.getTopRankers());
