class Person
{
    name: string;
    age: number;

    constructor(name:string , age:number)
    { 
        this.name=name;
        this.age=age;
    }

    getDetails():string
    {
        return this.name + "," +this.age;
    }
}

class Student extends Person
{
    studentid:number;
    marks:number;

    constructor(studentname: string , studentage:number, studentid: number, marks:number)
        {
            super(studentname,studentage);
            this.studentid=studentid;
            this.marks=marks;
        }
    getDetails():string
    {
        return this.name+"," +this.age +","+ this.studentid +"" +this.marks ;
    }
}

var p=new Person("Scott",20)
console.log(p.name);
console.log(p.age);
console.log(p.getDetails());

console.log("-----------------------------")

var s=new Student("Smith",22,201,67)
console.log(s.name);
console.log(s.age);
console.log(s.studentid);
console.log(s.marks);
console.log(s.getDetails());
