var s : string ="Hello";
console.log(s);