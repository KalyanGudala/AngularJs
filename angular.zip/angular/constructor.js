var Student = /** @class */ (function () {
    function Student(studentId, studentName, marks) {
        if (studentId === void 0) { studentId = 0; }
        if (studentName === void 0) { studentName = "none"; }
        if (marks === void 0) { marks = 0; }
        this.studentId = studentId;
        this.studentName = studentName;
        this.marks = marks;
    }
    Student.prototype.getResults = function () {
        if (this.marks >= 35) {
            return "Pass";
        }
        else {
            return "Fail";
        }
    };
    return Student;
}());
var s1 = new Student(101, "Scott", 80);
console.log(s1.studentId);
console.log(s1.studentName);
console.log(s1.getResults());
var s2 = new Student(102, "James", 90);
console.log(s2.studentId);
console.log(s2.studentName);
console.log(s2.getResults());
var s3 = new Student(103, "thomas", 100);
console.log(s3.studentId);
console.log(s3.studentName);
console.log(s3.getResults());
