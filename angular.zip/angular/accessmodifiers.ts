class Student
{
    public studentid:number=101;
    private studentname:"Scott";
    protected marks:number=80;

    public display(): void
    {
        console.log("Student.display");
        console.log(this.studentid);
        console.log(this.studentname);
        console.log(this.marks);
    }
}

/*Child class */

class EngineeringStudent extends Student
{
  public display1(): void
  {
      console.log("EngineeringStudent.display1");
      console.log(this.studentid); // accessible
      //console.log(this.studentname);// not accessible
      console.log(this.marks);//accessible
  }
}

/* Other Class*/

class Test
{
    sampleMethod(){
     
        var s=new Student();
        s.display();//accessible
        var e=new EngineeringStudent();
        e.display1();//accessible
        console.log("-------------");
        console.log(s.studentid);//accessible
        //console.log(s.studentname);// not accessible
        //console.log(s.marks;//not accessible
    }

}

var t: Test =new Test();
t.sampleMethod(); 
