var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Student = /** @class */ (function () {
    function Student() {
        this.studentid = 101;
        this.marks = 80;
    }
    Student.prototype.display = function () {
        console.log("Student.display");
        console.log(this.studentid);
        console.log(this.studentname);
        console.log(this.marks);
    };
    return Student;
}());
/*Child class */
var EngineeringStudent = /** @class */ (function (_super) {
    __extends(EngineeringStudent, _super);
    function EngineeringStudent() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EngineeringStudent.prototype.display1 = function () {
        console.log("EngineeringStudent.display1");
        console.log(this.studentid); // accessible
        //console.log(this.studentname);// not accessible
        console.log(this.marks); //accessible
    };
    return EngineeringStudent;
}(Student));
/* Other Class*/
var Test = /** @class */ (function () {
    function Test() {
    }
    Test.prototype.sampleMethod = function () {
        var s = new Student();
        s.display(); //accessible
        var e = new EngineeringStudent();
        e.display1(); //accessible
        console.log("-------------");
        console.log(s.studentid); //accessible
        //console.log(s.studentname);// not accessible
        //console.log(s.marks;//not accessible
    };
    return Test;
}());
var t = new Test();
t.sampleMethod();
