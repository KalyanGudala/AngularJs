"use strict";
exports.__esModule = true;
var Student = /** @class */ (function () {
    function Student(studentId, studentName, marks) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.marks = marks;
    }
    return Student;
}());
exports.Student = Student;
