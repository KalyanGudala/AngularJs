var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Person = /** @class */ (function () {
    function Person(name, age) {
        this.name = name;
        this.age = age;
    }
    Person.prototype.getDetails = function () {
        return this.name + "," + this.age;
    };
    return Person;
}());
var Student = /** @class */ (function (_super) {
    __extends(Student, _super);
    function Student(studentname, studentage, studentid, marks) {
        var _this = _super.call(this, studentname, studentage) || this;
        _this.studentid = studentid;
        _this.marks = marks;
        return _this;
    }
    Student.prototype.getDetails = function () {
        return this.name + "," + this.age + "," + this.studentid + "" + this.marks;
    };
    return Student;
}(Person));
var p = new Person("Scott", 20);
console.log(p.name);
console.log(p.age);
console.log(p.getDetails());
console.log("-----------------------------");
var s = new Student("Smith", 22, 201, 67);
console.log(s.name);
console.log(s.age);
console.log(s.studentid);
console.log(s.marks);
console.log(s.getDetails());
