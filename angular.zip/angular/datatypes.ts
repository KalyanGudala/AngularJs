var a:number =10;
var b:string="Hello";
var c:boolean=true;
var d:any =100;
console.log(a);
console.log(b);
console.log(c);
console.log(d);
