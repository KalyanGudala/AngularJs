import {Student} from "./Student";
class StudentsList
{
    students:Student[]=[
        new Student(101,"Scott",80),
        new Student(102,"Adams",90),
        new Student(103,"John",100),
        new Student(104,"David",110)
    ];

getTopRankers():Student
{
   var index;
   var max = 0;

   for(var i in this.students)
   {
       if(this.students[i].marks>max)
       {
           index =i;
       }
   }
   return this.students[index];
}

}

var s:StudentsList=new StudentsList();
console.log(s.getTopRankers());
