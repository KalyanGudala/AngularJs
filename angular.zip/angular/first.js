var s = "Hello";
console.log(s);
