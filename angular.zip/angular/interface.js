var Student = /** @class */ (function () {
    function Student() {
    }
    Student.prototype.getFullName = function () {
        return this.firstName + " " + this.lastName;
    };
    return Student;
}());
var s = new Student();
s.firstName = "Adam";
s.lastName = "Smith";
console.log(s.getFullName());
