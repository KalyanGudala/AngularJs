class Student
{
    studentId: number;
    studentName: string;
    marks : number;

    getResults()
    {
        if(this.marks>35)
        {
            return "Pass";
        }
        else{
            return "Fail";
        }
    }
}
var s1=new Student();
s1.studentId=101;
s1.studentName="Scott";
s1.marks=80;
console.log(s1.studentId);
console.log(s1.studentName);
console.log(s1.marks);
console.log(s1.getResults());

var s2=new Student();
s2.studentId=102;
s2.studentName="Scott";
s2.marks=90;
console.log(s2.studentId);
console.log(s2.studentName);
console.log(s2.marks);
console.log(s2.getResults());


