class Student
{
    studentId:number;
    studentName:string;
    marks:number;

    constructor(studentId:number=0,studentName:string="none",marks:number=0)
    {
       this.studentId=studentId;
       this.studentName=studentName;
       this.marks=marks;

    }
    
    getResults()
    {
        if(this.marks>=35)
        {
            return "Pass";
        }

        else{
            return "Fail";
        }
    }

}

var s1=new Student(101,"Scott",80)
console.log(s1.studentId);
console.log(s1.studentName);
console.log(s1.getResults());

var s2=new Student(102,"James",90)
console.log(s2.studentId);
console.log(s2.studentName);
console.log(s2.getResults());

var s3=new Student(103,"thomas",100)
console.log(s3.studentId);
console.log(s3.studentName);
console.log(s3.getResults());
