var courseNames;
(function (courseNames) {
    courseNames[courseNames["Java"] = 0] = "Java";
    courseNames[courseNames["Springboot"] = 1] = "Springboot";
    courseNames[courseNames["MicroServices"] = 2] = "MicroServices";
    courseNames[courseNames["Angularjs"] = 3] = "Angularjs";
    courseNames[courseNames["Reactjs"] = 4] = "Reactjs";
    courseNames[courseNames["JavaScript"] = 5] = "JavaScript";
})(courseNames || (courseNames = {}));
var Student = /** @class */ (function () {
    function Student() {
    }
    return Student;
}());
var s = new Student();
s.studentname = "Scott";
s.age = 20;
s.course = courseNames.MicroServices;
console.log(s.studentname);
console.log(s.age);
console.log(courseNames[s.course]);
