var a = 10;
var b = "Hello";
var c = true;
var d = 100;
console.log(a);
console.log(b);
console.log(c);
console.log(d);
