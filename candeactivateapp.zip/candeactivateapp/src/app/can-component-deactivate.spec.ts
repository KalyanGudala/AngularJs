import { CanComponentDeactivate } from './can-component-deactivate';

describe('CanComponentDeactivate', () => {
  it('should create an instance', () => {
    expect(new CanComponentDeactivate()).toBeTruthy();
  });
});
