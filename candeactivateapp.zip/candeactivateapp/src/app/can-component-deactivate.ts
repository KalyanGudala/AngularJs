export class CanComponentDeactivate {
    canNavigate:boolean;
}
